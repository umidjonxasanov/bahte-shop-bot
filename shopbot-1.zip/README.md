# BAHTE SHOP — Brutalist Telegram Bot

Онлайн дукон учун тайёр Telegram бот. Тил танлаш (UZ/RU), каталог, саватча,
буюртма, тўлов (naqd + Click/Payme) ва сайтга ўтувчи **WebApp** тугмаси.

## 1. Талаб қилинадиган нарсалар

- Python 3.10+
- Telegram bot tokeni ([@BotFather](https://t.me/BotFather) орқали)
- (Ихтиёрий) Click ёки Payme тўлов провайдер токени — @BotFather ичида
  `/mybots → Payments` бўлимидан олинади
- Сизнинг сайтингиз **https://** манзили (WebApp фақат https билан ишлайди!)

## 1.1. Ботни @BotFather'да яратиш (username: `bahte_shop_bot`)

1. Telegram'да [@BotFather](https://t.me/BotFather) билан чат очинг.
2. `/newbot` буйруғини юборинг.
3. Ботнинг кўрсатиладиган номини сўраганда — масалан: `BAHTE SHOP`.
4. Username сўраганда — аниқ шуни ёзинг: `bahte_shop_bot`
   (агар банд бўлса, BotFather хабар беради — `bahte_shop_uz_bot` каби вариант синаб кўринг).
5. BotFather сизга **токен** беради (масалан `123456789:AA...`) — уни нусхалаб,
   пастдаги 2-бўлимдаги `.env` файлига қўйинг.
6. Шу ерда логотипни ҳам қўйиб қўйишингиз мумкин — 4-бўлимга қаранг.

## 2. Ўрнатиш

```bash
cd shopbot
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

`.env.example` файлини `.env` номи билан нусхалаб, ичини тўлдиринг:

```bash
cp .env.example .env
```

```
BOT_TOKEN=123456789:AA...........................
WEBSITE_URL=https://sizning-saytingiz.uz
PAYMENT_PROVIDER_TOKEN=          # bo'sh qoldirsa ham bo'ladi
ADMIN_CHAT_ID=123456789
CURRENCY=UZS
```

**ADMIN_CHAT_ID** ни олиш учун ботга биринчи хабар юборинг, сўнг
[@userinfobot](https://t.me/userinfobot) орқали ўзингизнинг ID'ингизни билиб олинг.

## 3. Ботни ишга тушириш

```bash
python3 main.py
```

Бот polling режимида ишлайди (сервер/VPS/ноутбук — доим ёниқ туриши керак).
Продакшн учун `systemd`, `pm2`, ёки Docker'да фон режимида ишга туширинг.

## 4. Аватар ва профиль

`avatar.png` (512×512) — сиз юборган **BAHTE SHOP®** логотипи асосида тайёрланган.

1. Telegram'да **@BotFather** → `/mybots` → `bahte_shop_bot`ни танланг →
   **Edit Bot** → **Edit Botpic** → `avatar.png` файлини юборинг.
2. Шу ерда **Edit Description** ва **Edit About** ни ҳам тўлдиринг, масалан:
   - *Description* (бот ичкарисида, `/start`дан олдин кўринади):
     `BAHTE SHOP® — brutal uslubdagi onlayn do'kon. Katalog, buyurtma, yetkazib berish — bir joyda.`
   - *About* (профил қисқа матни):
     `BAHTE SHOP® | Rasmiy onlayn do'kon boti`
3. `make_avatar.py` файли энди фойдаланилмайди (генератив аватар ўрнига
   реал логотип қўйилди), лекин архивда сақланиб қолди — керак бўлса ўчириб
   ташлашингиз мумкин.

## 5. Сайтни ботга улаш (тайёр — `site/index.html`)

Сиз юборган сайт (`erkaklar-dokoni-demo-3.html` → архивда `site/index.html`)
аллақачон Telegram Mini App сифатида ёзилган экан: каталог, саватча,
буюртма формаси ва `tg.sendData(...)` орқали буюртмани ботга юбориш —
ҳаммаси ичкарида бор. Мен фақат кичик такомиллаштиришлар қилдим
(`tg.expand()`, header/background ранги, theme-color) ва бот томонида
буюртмани қабул қилиб оладиган handler қўшдим (`main.py` даги
`on_web_app_order`).

### Қандай ишлайди
1. Фойдаланувчи ботда **"🛍 DO'KONNI OCHISH"** тугмасини босади.
2. Сиз хостинг қилган `site/index.html` Telegram ичида очилади — каталог,
   саватча, "BUYURTMANI YUBORISH" формаси шу ерда.
3. Форма юборилганда сайт `tg.sendData(JSON)` орқали буюртмани (исм,
   телефон, манзил, тўлов тури, маҳсулотлар, жами сумма) ботга юборади ва
   ойнани ёпади (`tg.close()`).
4. Бот бу маълумотни `web_app_data` сифатида қабул қилади, SQLite'га
   ёзади, фойдаланувчига тасдиқ юборади ва админ группага хабар қилади.
5. Агар тўлов тури `click`/`payme` бўлса ва `PAYMENT_PROVIDER_TOKEN`
   созланган бўлса — бот автоматик равишда онлайн-тўлов инвойсини юборади.

### A) Сайтни ҳостинг қилиш (МАЖБУРИЙ — https керак)

Telegram WebApp **фақат https манзилда** ишлайди. Энг тез вариантлар:

**Netlify (энг осон, 2 дақиқа):**
1. https://app.netlify.com/drop сайтига киринг.
2. `site` папкасини (ёки ичидаги `index.html`ни) шу ерга судраб ташланг.
3. Сизга дарҳол `https://random-nom.netlify.app` манзили берилади.

**GitHub Pages:**
1. GitHub'да янги репозиторий очинг, `site/index.html` ни `index.html`
   номи билан юкланг.
2. Repo → Settings → Pages → Branch: `main` → Save.
3. Манзил: `https://username.github.io/repo-nomi/`

**Ёки ўзингизнинг hostingингиз** бўлса — `site/index.html` файлини
`public_html` (ёки шунга ўхшаш) папкага юкланг.

Домен тайёр бўлгач, `.env` файлида:

```
WEBSITE_URL=https://sizning-domeningiz.uz
```

### B) BotFather'да "Menu Button" сифатида ҳам қўшиш (тавсия этилади)

Бундай қилсангиз, фойдаланувчилар чат остидаги 🛍 тугма орқали ҳам
тўғридан-тўғри дўконни очишлари мумкин бўлади:

1. @BotFather → `/mybots` → `bahte_shop_bot` → **Bot Settings** →
   **Menu Button** → **Configure menu button**.
2. URL сифатида худди шу `https://sizning-domeningiz.uz` манзилини киритинг.
3. Тугма номи: `Do'kon` ёки `Shop`.

### Google Sheets webhook ҳақида

Сайт кодида (`SHEET_ENDPOINT`) буюртмаларни Google Sheets'га ҳам ёзиб
қўядиган ўзингизнинг скриптингиз бор экан — уни ўзгартирмадим, у
ҳостинг қилингандан кейин одатдагидек ишлайверади (боtga буюртма
юборилиши билан бир вақтда Sheets'га ҳам ёзилади).

## 6. Тўлов (Click / Payme)

1. @BotFather → ботингиз → `Payments` → рўйхатдан **Click** ёки **Payme**ни
   танланг → уларнинг сайтида мерчант сифатида рўйхатдан ўтиб, provider
   token оласиз.
2. Токенни `.env` файлидаги `PAYMENT_PROVIDER_TOKEN` га қўйинг.
3. Токен бўлмаса — бот автоматик равишда фақат **"NAQD (yetkazganda)"**
   тўлов усулини кўрсатади, ҳеч нарса бузилмайди.

## 7. Маҳсулотлар каталогини тўлдириш

`data/products.json` файлини очиб, ҳар бир маҳсулот учун:

```json
{
  "id": "p004",
  "photo": "https://sizning-saytingiz.uz/img/mahsulot4.jpg",
  "price": 150000,
  "name": {"uz": "NOM UZ", "ru": "НАЗВАНИЕ RU"},
  "desc": {"uz": "Brutal tavsif...", "ru": "Брутальное описание..."},
  "site_url": "https://sizning-saytingiz.uz/product/p004"
}
```

кўринишида қўшиб боринг. `photo` майдонига реал маҳсулот расмингиз URL'ини
қўйишингиз керак (ёки сайтингиздаги расмлар йўлини).

## 8. Файллар тузилиши

```
shopbot/
├── main.py            # bot ishga tushirish nuqtasi + barcha handlerlar
├── config.py          # .env dan sozlamalarni o'qish
├── database.py        # SQLite: foydalanuvchi, savatcha, buyurtmalar
├── keyboards.py        # tugmalar (reply/inline/WebApp)
├── texts.py            # UZ/RU brutal-uslub matnlar
├── products.py         # katalogni JSON'dan o'qish
├── data/products.json  # mahsulotlar ro'yxati (bot ichidagi mini-katalog uchun)
├── site/index.html      # SIZNING TAYYOR SAYTINGIZ — hostingga shu joylanadi
├── avatar.png           # botning brutal avatari (512x512, sizning logotipingiz)
├── make_avatar.py       # (endi ishlatilmaydi, ixtiyoriy)
├── requirements.txt
└── .env.example
```

## 9. Ҳозирги ҳолат

✅ Сайт (`site/index.html`) ботга тўлиқ уланган — буюртма формаси
тўғридан-тўғри ботга келади.
✅ Аватар — сизнинг BAHTE SHOP® логотипингиз.
✅ Тил, каталог, саватча, буюртма, тўлов — барчаси ишлайди.

**Сиздан керак бўлган ягона қадам:** `site/index.html`ни юқоридаги
5-бўлимдаги (Netlify/GitHub Pages/ўз hostingингиз) усуллардан бирида
жойлаштириб, унинг https-манзилини `.env` файлидаги `WEBSITE_URL`га
қўйиш, сўнг `BOT_TOKEN`ни `.env`га қўшиб, `python3 main.py` билан ишга
тушириш.

Агар маҳсулотлар расмлари ва нархларини ҳам сайт ичида (`site/index.html`
даги `products` массиви) ёки бот каталогида (`data/products.json`)
янгилашда ёрдам керак бўлса — реал маҳсулот рўйхатингизни юборинг.
