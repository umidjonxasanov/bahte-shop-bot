from PIL import Image, ImageDraw, ImageFont

W = H = 512
BLACK = (10, 10, 10)
YELLOW = (242, 226, 5)
WHITE = (255, 255, 255)

img = Image.new("RGB", (W, H), YELLOW)
d = ImageDraw.Draw(img)

FONT = "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"

# thick outer black frame
border = 22
d.rectangle([0, 0, W - 1, H - 1], outline=BLACK, width=border)

# inner black block
d.rectangle([40, 40, W - 40, H - 40], fill=BLACK)
d.rectangle([64, 64, W - 64, H - 64], fill=YELLOW)

# top black bar with SHOP text
d.rectangle([64, 64, W - 64, 160], fill=BLACK)
f_top = ImageFont.truetype(FONT, 60)
txt = "SHOP"
bbox = d.textbbox((0, 0), txt, font=f_top)
tw = bbox[2] - bbox[0]
d.text(((W - tw) / 2, 74), txt, font=f_top, fill=YELLOW)

# middle white panel with icon shapes
d.rectangle([88, 176, W - 88, 336], fill=WHITE, outline=BLACK, width=14)
d.line([88, 256, W - 88, 256], fill=BLACK, width=10)

# simple bold geometric icon: square, triangle, circle
cy = 216
d.rectangle([130, cy - 26, 182, cy + 26], fill=BLACK)  # square
d.polygon([(226, cy + 26), (256, cy - 30), (286, cy + 26)], fill=BLACK)  # triangle
d.ellipse([330, cy - 26, 382, cy + 26], fill=BLACK)  # circle

f_mid = ImageFont.truetype(FONT, 30)
txt2 = "MARKET"
bbox = d.textbbox((0, 0), txt2, font=f_mid)
tw = bbox[2] - bbox[0]
d.text(((W - tw) / 2, 288), txt2, font=f_mid, fill=BLACK)

# bottom black bar with BRUTAL text
d.rectangle([64, 352, W - 64, 448], fill=BLACK)
f_bot = ImageFont.truetype(FONT, 34)
txt3 = "B R U T A L"
bbox = d.textbbox((0, 0), txt3, font=f_bot)
tw = bbox[2] - bbox[0]
d.text(((W - tw) / 2, 386), txt3, font=f_bot, fill=YELLOW)

img.save("/home/claude/shopbot/avatar.png")
print("saved")
